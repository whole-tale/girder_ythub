# Tale: "Water Tale" in BDBag Format

Demonstration of how to use Whole Tale to develop custom analysis and visualization for data published externally via DataONE.  See https://wholetale.readthedocs.io/en/stable/users_guide/quickstart.html for more information.

# How to run?

```
sh ./run.sh
```

Access on http://localhost:8888/?token=wholetale
